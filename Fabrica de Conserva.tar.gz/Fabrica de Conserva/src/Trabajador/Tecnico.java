
package Trabajador;

public class Tecnico extends Trabajador{
    private String especialidad;
    public Tecnico(String nombre, String CI, String direccion, int telefono) {
        super(nombre, CI, direccion, telefono);
        this.especialidad = especialidad;
    }
    
}
