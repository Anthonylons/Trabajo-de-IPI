
package Trabajador;


public abstract class Trabajador {
    protected String nombre;
    protected String CI;
    protected String direccion;
    protected int telefono;
    
    public Trabajador(String nombre,String CI,String direccion,int telefono){
        this.CI = CI;
        this.direccion = direccion;
        this.nombre = nombre;
        this.telefono = telefono;
    }
}
