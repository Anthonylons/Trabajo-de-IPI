
package Trabajador;

public class TDirecto extends Trabajador{
    private int anoExp;

    public TDirecto(String nombre, String CI, String direccion, int telefono,int anoExp) {
        super(nombre, CI, direccion, telefono);
        this.anoExp = anoExp;
    }
}
