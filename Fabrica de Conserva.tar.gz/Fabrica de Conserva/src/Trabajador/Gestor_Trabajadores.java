
package Trabajador;
import Extra.Lista;


public class Gestor_Trabajadores {
    private Lista<Trabajador> trabajadores;
    private int max;
    
    public Gestor_Trabajadores(int max){
        this.max = max;
        trabajadores = new Lista<Trabajador>(this.max);
    }
    
    public void add(String nombre, String CI, String direccion,
            int telefono,String tCientifico,String centro){
        this.trabajadores.add(new Profesional(nombre, CI, direccion, telefono, tCientifico, centro));
    }
    
    public void add(String nombre, String CI, String direccion, int telefono,int anoExp){
        this.trabajadores.add(new TDirecto(nombre, CI, direccion, telefono, anoExp));
    }
    
    public void add(String nombre, String CI, String direccion, int telefono){
        this.trabajadores.add(new Tecnico(nombre, CI, direccion, telefono));
    }
}
