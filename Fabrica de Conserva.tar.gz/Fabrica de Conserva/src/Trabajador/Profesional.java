
package Trabajador;

public class Profesional extends Trabajador{
    private String tCientifico;
    private String centro;
    public Profesional(String nombre, String CI, String direccion,
            int telefono,String tCientifico,String centro) {
        super(nombre, CI, direccion, telefono);
        this.tCientifico = tCientifico;
        this.centro = centro;
    }
    
}
