
package Extra;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Fichero {
    public void txtCrearProducto(){
        try {
            FileReader entrada = new FileReader("C:/Users/Landy/Documents/NetBeansProjects/Fabrica de Conserva/Datos producto.txt");
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Fichero.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("No encontrado");
        }
    }
}
