
package Producto;


public class Producto implements Comparable{
    private String nombre;
    private int costoP;
    private String fechaV;
    private boolean exportable;
    private int[] produccionAnual = new int[12];
    private int index = 0;
    private int produccionTotal = 0;
    
    public Producto(String nombre,int costoP,String fechaV,boolean exportable){
        this.nombre = nombre;
        this.costoP = costoP;
        this.exportable = exportable;
        this.fechaV = fechaV;
    }
    
    public String getNombre(){
        return this.nombre;
    }
    
    public void addProduccion(int produccion){
        if(index == 12){
            //Va a;adiendo automaticamente producciones a los meses 
            //No se puede reasignar mas produccion a un mes
        }
        else{
           this.produccionAnual[index++] = produccion; 
        }
    }
    
    public boolean getExportable(){
        return this.exportable;
    }
    
    public int[] getMeses(){
        return this.produccionAnual;
    }
    
    public int calcularAnual(){
        for(int i = 0; i < 12; i++){
            this.produccionTotal += this.produccionAnual[i];
        }
        return this.produccionTotal;
    }
    
    public int getAnual(){
        return this.produccionTotal;
    }

    @Override
    public int compareTo(Object o) {
        Producto aux = (Producto) o;
        if(this.produccionTotal < aux.produccionTotal){
            return -1;
        }
        if(this.produccionTotal > aux.produccionTotal){
            return 1;
        }
        return 0;
    }
}
