
package Producto;
import Envase.GestorEnvase;
import Extra.Lista;
import java.util.Arrays;


public class GestorProducto{
    public Lista<Producto> prod = new Lista<Producto>(10);
    public GestorEnvase envases;
    private int maxP;
    private int maxE;
    
    public GestorProducto(){
        envases = new GestorEnvase(maxE);
    }
    
    public void addProductos(String nombre,int costoP,
            String fechaV,boolean exportable){
        Producto aux = new Producto(nombre, costoP, fechaV, exportable);
        try{
          prod.add(aux);  
        }catch(Exception ex){
            System.out.println("Lista LLlena");
        }
        
    }
    
    public int addProdccionMes(int pos,int cant){
        //compruebo si es de xporactacion y existe la cantidad
        if(this.prod.index(pos).getExportable() && envases.getDisponliblesE() >= cant){
           this.prod.index(pos).addProduccion(cant); 
           envases.utilizarE(cant);
           return 0;
        }
        if(this.prod.index(pos).getExportable()== false && envases.getDisponliblesN() >= cant){
            this.prod.index(pos).addProduccion(cant);
            envases.utilizarN(cant);
            return 0; 
        }
        return -1;
    }
    
    
    public int anualProduccion(String nombre){
        int produccion = 0;
        for(int i = 0;i < 10;i++){
            if(this.prod.index(i).getNombre().equals(nombre)){
                produccion = this.prod.index(i).calcularAnual();
                break;
            }
        }
        return produccion;
    }
    
    public int prodTotal(){
        int total = 0;
        for(int i = 9; i < 10; i++){
            total += this.prod.index(i).calcularAnual();
        }
        return total;
    }
    
    public double porcentaje(int plan){
        int total = prodTotal();
        return (total * 100) / plan;
    }
    
    //lista de productos ordenados segun su produccion anual
    public Producto[] anuales(){
        Producto[] aux = new Producto[10];
        //Actualizar
        for(int i = 0;i < 10;i++){
            this.prod.index(i).calcularAnual();
            aux[i] = this.prod.index(i);
        }
        Arrays.sort(aux);
        return aux;
    }
    
    public Producto[] exportacion(){
        Producto[] aux = new Producto[10];
        int real = 0;
        
        //Guardo todos los productos de exportacion
        for(int i = 0;i < 10;i++){
            if(this.prod.index(i).getExportable()){
                aux[real++] = prod.index(i);
            }
        }
        
        Producto[] aux1 = new Producto[real+1];
        for(int i = 0;i < real+1;i++){
            aux1[i] = aux[i];
        }
        return aux1;
    }
    
    public Producto datos(String nombre){
        for(int i = 0; i < 10;i++){
            if(this.prod.index(i).getNombre().equals(nombre)){
                return this.prod.index(i);
            }
        }
        return null;
    }
    
    public int[] mejorMes(){
        int[] meses = new int[12];
        for(int i = 0; i < 10;i++){
            int[] aux = this.prod.index(i).getMeses();
            for(int j = 0; j < 12;j++){
                for(int z = 0;z < 12; z++){
                    meses[j] += aux[z];
                }
            }
        }
        
        int max = -99999999;
        int index = 0;
        for(int i = 0;i < 12;i++){
            if(meses[i] > max){
                max = meses[i];
                index = i;
            }
        }
        int[] dates = new int[2];
        return dates;
    }
    
    
}

