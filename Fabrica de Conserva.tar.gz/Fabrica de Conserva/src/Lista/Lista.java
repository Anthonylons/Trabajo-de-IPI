
package Lista;

public class Lista<T> {
    private int real;
    private int max;
    private T[] elementos;
    
    
    public Lista(int max) {
        this.real = 0;
        this.max = max;
        this.elementos = (T[]) new Object[max];
    }
    
    public void add(T element){
        elementos[real++] = element;
    }
    
    public void delete(int pos){
        for(int i = pos - 1;i < real;i++){
            elementos[i] = elementos[i+1];
        }
        real--;
    }
    
    public T index(int pos){
        return elementos[pos-1];
    }
    
    public int length(){
        return real;
    }
    
    public boolean empty(){
        if(real==0){
            return true;
        }
        return false;
    }
}
