package fabrica;


import Envase.GestorEnvase;
import Extra.Lista;
import Producto.GestorProducto;
import Producto.Producto;
import Trabajador.Gestor_Trabajadores;
import fabrica.CrearProductos;
import java.awt.Component;
import javax.swing.JFrame;

public class  Fabrica {
    public Gestor_Trabajadores trabajadores;
    public GestorEnvase envases;
    public GestorProducto productos;
    public CrearProductos menu;
    Object[] datos;
    
    public Fabrica(){
        this.trabajadores = new Gestor_Trabajadores(500);
        this.envases = new  GestorEnvase(999999);
        this.productos = new GestorProducto();
    }
    
    public void crearProductos(){
        CrearProductos vent = new CrearProductos(this);
        vent.setVisible(true);
    }
    
    public void getValues(CrearProductos u1){
        datos = u1.datos();
        productos.addProductos((String) datos[0],(int) datos[1], (String) datos[2],(boolean) datos[3]);
    }
    
    public String[] nombresproductos(){
        String[] aux = new String[10];
        Lista<Producto> uax = productos.prod;
        try{
           for(int i = 0; i < 10;i++){
            aux[i] = uax.index(i).getNombre();
        } 
        }catch(Exception e){
            System.out.println("Faltan datos");
        }
        
        return aux;
    }
        
    
}