
package Envase;
import Extra.Lista;


public class GestorEnvase {
    private int max;
    private Lista<Envase> envases;
    private int disponilbeN;
    private int disponilbeE;
    
    public GestorEnvase(int max){
        this.max = max;
        envases = new Lista<Envase>(this.max);
    }
    
    public void add(int precio,String provedor){
        Enacional aux = new Enacional(precio, provedor);
        this.envases.add(aux);
        this.disponilbeN++;
        System.out.println("Envase Creado");
    }
    
    public void add(int precio,String pais,int horasTransportacion){
        eExportacion aux = new eExportacion(precio, pais, horasTransportacion);
        this.envases.add(aux);
        this.disponilbeE++;
        System.out.println("Envase Creado");
    }
    
    public int getDisponliblesN(){
        return this.disponilbeN;
    }
    
    public int getDisponliblesE(){
        return this.disponilbeE;
    }
    
    public void utilizarN(int cant){
        this.disponilbeN -= cant;
    }
    
    public void utilizarE(int cant){
        this.disponilbeE -= cant;
    }
}
