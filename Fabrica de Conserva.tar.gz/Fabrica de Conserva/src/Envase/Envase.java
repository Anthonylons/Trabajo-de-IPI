
package Envase;

public abstract class Envase {
    protected int precio;
    
    public Envase(int precio){
        this.precio = precio;
    }
}
