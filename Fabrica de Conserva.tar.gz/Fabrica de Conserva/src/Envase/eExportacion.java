
package Envase;


public class eExportacion extends Envase{
    private String pais;
    private int horasTransportacion;

    public eExportacion(int precio,String pais,int horasTransportacion) {
        super(precio);
        this.pais = pais;
        this.horasTransportacion = horasTransportacion;
    }
}
