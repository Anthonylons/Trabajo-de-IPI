
package Envase;


public class Enacional extends Envase{
    private String provedor;

    public Enacional(int precio,String provedor) {
        super(precio);
        this.provedor = provedor;
    }
}
